CREATE TRIGGER after_supply_insert
    AFTER INSERT ON Supplies
BEGIN
    INSERT INTO Components (component_type, material, quantity)
    VALUES (NEW.component_type, NEW.material, NEW.quantity)
    ON CONFLICT(component_type, material) DO UPDATE SET
        quantity = quantity + EXCLUDED.quantity;
END;

